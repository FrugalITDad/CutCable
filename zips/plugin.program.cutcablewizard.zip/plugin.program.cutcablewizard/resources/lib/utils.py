import xbmc
import xbmcgui
import xbmcaddon
import os

addon = xbmcaddon.Addon()
ADDON_ID = addon.getAddonInfo('id')
PROFILE = addon.getAddonInfo('profile')

def first_run_wizard():
    xbmcgui.Dialog().ok(
        "Welcome to CutCable",
        "This wizard will help you install and manage",
        "your CutCable Kodi build."
    )

def notify(title, message, time=3000):
    xbmcgui.Dialog().notification(title, message, time=time)

def ensure_path(path):
    if not os.path.exists(path):
        os.makedirs(path)

def log(msg):
    xbmc.log(f"[CutCable Wizard] {msg}", xbmc.LOGINFO)
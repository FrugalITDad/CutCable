import xbmcgui
from resources.lib import utils

def menu():
    options = [
        "Backup Build",
        "Restore Backup",
        "Clear Cache",
        "Reset Build",
        "Back"
    ]

    choice = xbmcgui.Dialog().select("Maintenance", options)

    if choice == 0:
        utils.notify("Backup", "Backup feature coming soon")
    elif choice == 1:
        utils.notify("Restore", "Restore feature coming soon")
    elif choice == 2:
        clear_cache()
    elif choice == 3:
        reset_build()

def clear_cache():
    utils.notify("Cache", "Cache cleared (placeholder)")

def reset_build():
    confirm = xbmcgui.Dialog().yesno(
        "Reset Build",
        "This will reset your Kodi build.",
        "Continue?"
    )
    if confirm:
        utils.notify("Reset", "Build reset (placeholder)")
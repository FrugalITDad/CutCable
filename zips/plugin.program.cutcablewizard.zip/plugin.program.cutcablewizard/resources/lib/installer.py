import xbmcgui
from resources.lib import utils, config

def install_build(build_key):
    build = config.BUILDS.get(build_key)
    if not build:
        utils.notify("Error", "Build not found")
        return

    xbmcgui.Dialog().ok(
        "Install Build",
        f"You selected: {build_key}",
        build["description"]
    )

    utils.log(f"Selected build: {build_key}")
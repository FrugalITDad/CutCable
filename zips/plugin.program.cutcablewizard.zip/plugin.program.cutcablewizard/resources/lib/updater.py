def check_for_updates(silent=False):
    for build in installed_builds():
        local = get_local_version(build)
        remote = get_repo_version(build)

        if remote > local:
            if silent:
                install_update(build)
            else:
                prompt_user(build, remote)

import xbmcgui
from resources.lib import installer, updater, config

def build_menu():
    build_list = []

    for name, data in config.BUILDS.items():
        version = updater.get_repo_version(data["id"])
        build_list.append(f"{name}  [v{version}]")

    choice = xbmcgui.Dialog().select("Select Build", build_list)
    if choice >= 0:
        build_key = list(config.BUILDS.keys())[choice]
        installer.install_build(build_key)

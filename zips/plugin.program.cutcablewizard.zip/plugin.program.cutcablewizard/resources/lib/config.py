REPO_BASE = "https://frugalitdad.github.io/CutCable"
REPO_XML = f"{REPO_BASE}/addons.xml"
BUILDS_PATH = f"{REPO_BASE}/zips"

BUILDS = {
    "CutCableBasic": {
        "id": "cutcable.basic",
        "description": "Kodi Addons Only"
    },
    "CutCablePlus": {
        "id": "cutcable.plus",
        "description": "Kodi + 3rd Party Addons"
    },
    "CutCablePro": {
        "id": "cutcable.pro",
        "description": "Family Use Only"
    },
    "CutCablePlusGamer": {
        "id": "cutcable.plusgamer",
        "description": "3rd Party + Gaming"
    },
    "CutCableProGamer": {
        "id": "cutcable.progamer",
        "description": "Family + Gaming"
    },
    "CutCableAdmin": {
        "id": "cutcable.admin",
        "description": "Admin Use Only"
    }
}

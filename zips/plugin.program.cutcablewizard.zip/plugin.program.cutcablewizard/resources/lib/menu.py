import xbmcgui
from resources.lib import builds, maintenance, updater

def main_menu():
    options = [
        "Install / Update Builds",
        "Maintenance",
        "Check for Updates",
        "Exit"
    ]

    choice = xbmcgui.Dialog().select("CutCable Wizard", options)

    if choice == 0:
        builds.build_menu()
    elif choice == 1:
        maintenance.menu()
    elif choice == 2:
        updater.check_for_updates()

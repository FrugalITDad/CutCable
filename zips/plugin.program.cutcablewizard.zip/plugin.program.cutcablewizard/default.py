import xbmcaddon
from resources.lib import menu, updater, utils

addon = xbmcaddon.Addon()

# Auto update check on startup
if addon.getSettingBool("auto_update"):
    updater.check_for_updates(silent=True)

# First run wizard
if not addon.getSettingBool("first_run_complete"):
    utils.first_run_wizard()
    addon.setSettingBool("first_run_complete", True)

# Launch main menu
menu.main_menu()
